/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PembantasBarrel : MonoBehaviour
{
    // Start is called before the first frame update
    private void OnTriggerEnter2D(Collider2D collision)
    {

        // Jika objek yang bersentuhan memiliki tag "Player"
        if (collision.CompareTag("Barrier"))
        {
            Physics2D.IgnoreCollision(collision, GetComponent<Collider2D>());

        }
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
*/